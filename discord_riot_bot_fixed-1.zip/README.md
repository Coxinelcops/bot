# Discord Riot Bot

Ce bot Discord permet de récupérer le rang d’un joueur League of Legends via la commande `!rank <nom_du_joueur>`.

## Fichiers

- `main.py` : code principal du bot
- `requirements.txt` : dépendances
- `.env.example` : variables à définir
- `runtime.txt` : spécifie Python 3.11 pour éviter les erreurs avec audioop
- `render.yaml` : configuration pour Render

## Déploiement sur Render

1. Poussez ce projet sur GitHub
2. Créez un service Python sur Render relié à ce dépôt
3. Ajoutez vos variables d’environnement :
   - `RIOT_API_KEY`
   - `DISCORD_TOKEN`
4. Déploiement automatique avec `render.yaml`

## Commande disponible

```
!rank <nom_du_summoner>
```
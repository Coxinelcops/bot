import discord
import os
import requests
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
RIOT_API_KEY = os.getenv("RIOT_API_KEY")
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.command()
async def rank(ctx, summoner_name):
    response = requests.get(
        f"https://euw1.api.riotgames.com/lol/summoner/v4/summoners/by-name/{summoner_name}",
        headers={"X-Riot-Token": RIOT_API_KEY}
    )
    if response.status_code != 200:
        await ctx.send("Summoner not found or API error.")
        return

    summoner = response.json()
    summoner_id = summoner["id"]

    ranked_response = requests.get(
        f"https://euw1.api.riotgames.com/lol/league/v4/entries/by-summoner/{summoner_id}",
        headers={"X-Riot-Token": RIOT_API_KEY}
    )
    if ranked_response.status_code != 200:
        await ctx.send("Could not fetch ranked data.")
        return

    ranked_data = ranked_response.json()
    if not ranked_data:
        await ctx.send(f"{summoner_name} n'a pas de parties classées.")
        return

    solo_queue = next((entry for entry in ranked_data if entry["queueType"] == "RANKED_SOLO_5x5"), None)
    if solo_queue:
        tier = solo_queue["tier"]
        rank = solo_queue["rank"]
        lp = solo_queue["leaguePoints"]
        await ctx.send(f"{summoner_name} est classé {tier} {rank} avec {lp} LP.")
    else:
        await ctx.send(f"{summoner_name} n'a pas de classement en solo queue.")

bot.run(DISCORD_TOKEN)